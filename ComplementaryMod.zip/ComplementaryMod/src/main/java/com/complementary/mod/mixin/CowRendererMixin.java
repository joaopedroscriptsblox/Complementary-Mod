package com.complementary.mod.mixin;

import com.complementary.mod.client.BabyTextures;
import net.minecraft.client.renderer.entity.CowRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.Cow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(CowRenderer.class)
public abstract class CowRendererMixin {
    @Inject(method = "getTextureLocation(Lnet/minecraft/world/entity/animal/Cow;)Lnet/minecraft/resources/ResourceLocation;",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void cm$baby(Cow entity, CallbackInfoReturnable<ResourceLocation> cir) {
        if (entity.isBaby()) {
            cir.setReturnValue(BabyTextures.get(cir.getReturnValue()));
        }
    }
}
