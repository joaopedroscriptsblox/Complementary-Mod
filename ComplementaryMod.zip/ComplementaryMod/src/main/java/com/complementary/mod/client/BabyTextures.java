package com.complementary.mod.client;

import com.complementary.mod.ComplementaryMod;
import com.mojang.blaze3d.platform.NativeImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/** Cria, em tempo de execucao, uma versao mais clara e suave da textura de um mob para os filhotes. */
public final class BabyTextures {
    private static final Map<ResourceLocation, ResourceLocation> CACHE = new HashMap<>();
    private static final float LIGHTEN = 0.16f;

    private BabyTextures() {}

    public static ResourceLocation get(ResourceLocation vanilla) {
        ResourceLocation cached = CACHE.get(vanilla);
        if (cached != null) return cached;
        ResourceLocation result = build(vanilla);
        CACHE.put(vanilla, result);
        return result;
    }

    private static ResourceLocation build(ResourceLocation vanilla) {
        try {
            Minecraft mc = Minecraft.getInstance();
            var res = mc.getResourceManager().getResource(vanilla);
            if (res.isEmpty()) return vanilla;
            NativeImage img;
            try (InputStream in = res.get().open()) {
                img = NativeImage.read(in);
            }
            for (int y = 0; y < img.getHeight(); y++) {
                for (int x = 0; x < img.getWidth(); x++) {
                    int c = img.getPixelRGBA(x, y);
                    int a = (c >>> 24) & 255;
                    if (a == 0) continue;
                    int b = (c >>> 16) & 255;
                    int g = (c >>> 8) & 255;
                    int r = c & 255;
                    r += (int) ((255 - r) * LIGHTEN);
                    g += (int) ((255 - g) * LIGHTEN);
                    b += (int) ((255 - b) * LIGHTEN);
                    img.setPixelRGBA(x, y, (a << 24) | (b << 16) | (g << 8) | r);
                }
            }
            String name = "baby/" + vanilla.getPath().replace('/', '_').toLowerCase();
            ResourceLocation id = ComplementaryMod.id(name);
            mc.getTextureManager().register(id, new DynamicTexture(img));
            return id;
        } catch (Throwable t) {
            return vanilla;
        }
    }
}
