package com.complementary.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class ComplementaryMod implements ModInitializer {
    public static final String MOD_ID = "complementarymod";

    public static Block GOLDEN_DANDELION;
    public static Item GOLDEN_DANDELION_ITEM;

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        GOLDEN_DANDELION = Registry.register(BuiltInRegistries.BLOCK, id("golden_dandelion"),
                new FlowerBlock(MobEffects.GLOWING, 8.0f, BlockBehaviour.Properties.ofFullCopy(Blocks.DANDELION)));
        GOLDEN_DANDELION_ITEM = Registry.register(BuiltInRegistries.ITEM, id("golden_dandelion"),
                new BlockItem(GOLDEN_DANDELION, new Item.Properties()));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS)
                .register(entries -> entries.accept(GOLDEN_DANDELION_ITEM));
        CompostingChanceRegistry.INSTANCE.add(GOLDEN_DANDELION_ITEM, 0.65f);
    }
}
