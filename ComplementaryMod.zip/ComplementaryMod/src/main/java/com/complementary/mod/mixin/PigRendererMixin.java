package com.complementary.mod.mixin;

import com.complementary.mod.client.BabyTextures;
import net.minecraft.client.renderer.entity.PigRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.Pig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PigRenderer.class)
public abstract class PigRendererMixin {
    @Inject(method = "getTextureLocation(Lnet/minecraft/world/entity/animal/Pig;)Lnet/minecraft/resources/ResourceLocation;",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void cm$baby(Pig entity, CallbackInfoReturnable<ResourceLocation> cir) {
        if (entity.isBaby()) {
            cir.setReturnValue(BabyTextures.get(cir.getReturnValue()));
        }
    }
}
